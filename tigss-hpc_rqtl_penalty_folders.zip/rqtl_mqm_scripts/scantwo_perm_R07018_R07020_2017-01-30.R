# Calculate penalties for multiple-QTL mapping with R/qtl package
# (Much of this code originates from rqtl.org tutorials.)

#** Start Modify variables **
# phenotypes
phenotype_list = c("angle_leaf_3_avg_gh204A_2013_normalized",
                   "angle_leaf_4_avg_gh204A_2013_normalized")
#** End modify variables **

args <- commandArgs(TRUE)

operm_scantwo_filepath <- args[1]
setwd(file.path(operm_scantwo_filepath))

perms_per_job = args[2]

operm_scantwo_iteration <- paste(args[3], "operm_scantwo", sep="_")
operm_scantwo_name <- paste(operm_scantwo_iteration, "RDS", sep=".")

rqtl_cross_path <- file.path(args[4])
cross_file_path <- paste(rqtl_cross_path, "/", args[5], sep="")
cross_file_path <- file.path(cross_file_path)

library(qtl)

load(cross_file_path)

seed_number_base = 85842518
seed_number = seed_number_base + as.integer(args[3])
set.seed(seed_number)
operm_scantwo <- scantwo(cross=cross_inputcross, n.perm = as.integer(perms_per_job), pheno.col = phenotype_list, n.cluster = 8)
saveRDS(operm_scantwo, file = operm_scantwo_name)
