#!/bin/bash
# Tell the UGE that this is an array job, with "tasks" to be numbered 1 to 1250 in intervals of 1
#$ -l num_threads=8
#$ -l mem_free=32g
#$ -q normal.q
#$ -t 1-1250:1

SCANTWOPERM_R_FILEPATH=$1
SCANTWOPERMPATH=$2
PERMUTATIONS_PER_JOB=$3
RQTLCROSSPATH=$4
CROSS=$5
LOGPATH=$6

if [ -e ${SCANTWOPERMPATH}/${SGE_TASK_ID}_operm_scantwo.RDS ]
then
        echo `date` "--job array index:" ${SGE_TASK_ID} "already exists" 1>> ${LOGPATH}${SGE_TASK_ID}.o 2>> ${LOGPATH}${SGE_TASK_ID}.e
else
        echo `date` "--job array is on index:" ${SGE_TASK_ID} 1>> ${LOGPATH}${SGE_TASK_ID}.o 2>> ${LOGPATH}${SGE_TASK_ID}.e
	/data/thkhavi/downloads/R-3.3.2/bin/Rscript ${SCANTWOPERM_R_FILEPATH} ${SCANTWOPERMPATH} ${PERMUTATIONS_PER_JOB} ${SGE_TASK_ID} ${RQTLCROSSPATH} ${CROSS} 1>> ${LOGPATH}${SGE_TASK_ID}.o 2>> ${LOGPATH}${SGE_TASK_ID}.e
fi
