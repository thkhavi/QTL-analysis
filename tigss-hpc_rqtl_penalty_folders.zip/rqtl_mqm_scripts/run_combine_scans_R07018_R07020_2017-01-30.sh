#!/bin/bash
############
# bash script to combine scantwo permutations
# Written by Sandra K. Truong 2016/07/14

#** Start Modify variables **
# CROSS variable must be the same name as the cross object
CROSS="R07018_R07020_2017-01-30"
#** End modify variables **

COMBINESCANTWOPERM_R_FILEPATH=/data/thkhavi/rqtl_mqm_scripts/combine_scantwo_perms.R
CROSSPATH=/data/thkhavi/rqtl_mqm_output/${CROSS}/
SCANTWOPERMPATH=${CROSSPATH}operms_scantwo
COMBINESCANTWOPERMPATH=${CROSSPATH}mqm_scantwo_penalties/

/data/thkhavi/downloads/R-3.3.2/bin/Rscript ${COMBINESCANTWOPERM_R_FILEPATH} ${SCANTWOPERMPATH} ${COMBINESCANTWOPERMPATH}

