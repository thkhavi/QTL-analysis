#!/bin/bash
# bash script to run scantwo permutations
# Written by Sandra K. Truong 2016/07/14

#** Start Modify variables **
# CROSS variable must be the same name as the cross object
CROSS="R07018_R07020_2017-01-30"
#** End modify variables **

# Hardware values
NUMTHREADS=8
MEMORY="32g"

# permutations
PERMUTATIONS=25000
PERMUTATIONS_PER_JOB=20
NUMBER_OF_JOBS=$(($PERMUTATIONS / $PERMUTATIONS_PER_JOB))

# file paths
RQTLCROSSPATH=/data/thkhavi/rqtl_crosses
if [ -d "${RQTLCROSSPATH}" ]
then
        echo -e "RQTLCROSSPATH exists"
else
        echo -e "\n\tUnable to locate RQTLCROSS_FILEPATH. Creating directory...\n"
fi

RQTLCROSS_FILEPATH=/data/thkhavi/rqtl_crosses/${CROSS}
if [ -a "${RQTLCROSS_FILEPATH}" ]
then
        echo -e "RQTLCROSS_FILEPATH exists"
else
        echo -e "\n\tUnable to locate RQTLCROSS_FILEPATH.\n\tPlease make sure the R/qtl cross object is in the appropriate file.\n"
fi

CROSSPATH=/data/thkhavi/rqtl_mqm_output/${CROSS}/
if [ -d ${CROSSPATH} ]
then
	echo -e "CROSSPATH exists"
else
	echo -e "\n\tUnable to locate CROSSPATH. Creating directory...\n"
	mkdir ${CROSSPATH}
fi

LOGPATH=${CROSSPATH}logs/
if [ -d ${LOGPATH} ]
then
        echo -e "LOGPATH exists"
else
        echo -e "\n\tUnable to locate LOGPATH. Creating directory...\n"
        mkdir ${LOGPATH}
fi

SCANTWOPERM_R_FILEPATH=/data/thkhavi/rqtl_mqm_scripts/scantwo_perm_${CROSS}.R
SCANTWOPERM_BASH_FILEPATH=/data/thkhavi/rqtl_mqm_scripts/scantwo_perm_jobarray.sh

SCANTWOPERMPATH=${CROSSPATH}operms_scantwo
if [ -d ${SCANTWOPERMPATH} ]
then
        echo -e "SCANTWOPERMPATH exists"
else
        echo -e "\n\tUnable to locate SCANTWOPERMPATH. Creating directory...\n"
        mkdir ${SCANTWOPERMPATH}
fi

COMBINESCANTWOPERM_R_FILEPATH=/data/thkhavi/rqtl_mqm_scripts/combine_scantwo_perms.R

COMBINESCANTWOPERMPATH=${CROSSPATH}mqm_scantwo_penalties/
if [ -d ${COMBINESCANTWOPERMPATH} ]
then
        echo -e "COMBINESCANTWOPERMPATH exists"
else
        echo -e "\n\tUnable to locate COMBINESCANTWOPERMPATH. Creating directory...\n"
        mkdir ${COMBINESCANTWOPERMPATH}
fi

# Perform scantwo permutations

qsub ${SCANTWOPERM_BASH_FILEPATH} ${SCANTWOPERM_R_FILEPATH} ${SCANTWOPERMPATH} ${PERMUTATIONS_PER_JOB} ${RQTLCROSSPATH} ${CROSS} ${LOGPATH}

echo `date` "Queued scantwo permutations for" ${CROSS}
